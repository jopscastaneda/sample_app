require 'rails_helper'

RSpec.describe Comment, type: :model do
	context 'Add Comment tests' do
	it 'ensures username not blank' do
		comment = Comment.new(body: 'comment').save 
		expect(comment).to eq(false)
	end

	it 'ensures comment not blank' do
		comment = Comment.new(username: 'name').save 
		expect(comment).to eq(false)
	end

	it 'should save add comment succesfully' do
		comment = Comment.new(username: 'name', body: 'comment').save 
		expect(comment).to eq(false)
	end

	end
	
	context 'scope tests' do
	end

end
