require 'rails_helper'

RSpec.describe Post, type: :model do
  	context 'Add Post tests' do

	it 'ensures title not blank' do
		post = Post.new(body: 'sampleBody').save 
		expect(post).to eq(false)
	end

	it 'ensures body not blank' do
		post = Post.new(title: 'sampleTitle').save 
		expect(post).to eq(false)
	end


	it 'should save add post succesfully' do
		post = Post.new(title: 'sampleTitle', body: 'sampleBody').save 
		expect(post).to eq(true)
	end

	end
	
	context 'Update Post tests' do

	it 'ensures update title not blank' do
	end

	it 'ensures update body not blank' do
	end

	it 'ensures update post is saved' do
	end

	end

	context 'Delete Post tests' do

	it 'ensures post is deleted' do
	end
end
end
