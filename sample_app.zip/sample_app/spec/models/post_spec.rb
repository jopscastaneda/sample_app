require 'rails_helper'

RSpec.describe Post, type: :model do
  	context 'Add Post tests' do

	it 'ensures title not blank' do
		post = Post.new(body: 'sampleBody').save 
		expect(post).to eq(false)
	end

	it 'ensures body not blank' do
		post = Post.new(title: 'sampleTitle').save 
		expect(post).to eq(false)
	end


	it 'should save add post succesfully' do
		post = Post.new(title: 'sampleTitle', body: 'sampleBody').save 
		expect(post).to eq(true)
	end

	end
	
	context 'scope tests' do
	end
end
