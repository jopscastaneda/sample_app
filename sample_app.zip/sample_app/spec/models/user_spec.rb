require 'rails_helper'

RSpec.describe User, type: :model do
	context 'Registration tests' do

	it 'ensures name not blank' do
		user = User.new(email: 'sample@example.com', password: '123456', password_confirmation: '123456').save 
		expect(user).to eq(false)
	end

	it 'ensures email not blank' do
		user = User.new(name: 'name', password: '123456', password_confirmation: '123456').save 
		expect(user).to eq(false)
	end

	it 'ensures password not blank' do
		user = User.new(name: 'name', email: 'sample@example.com', password_confirmation: '123456').save 
		expect(user).to eq(false)
	end

	it 'ensures password_confirmation not blank' do
		user = User.new(name: 'name', email: 'sample@example.com', password: '123456').save 
		expect(user).to eq(false)
	end

	it 'should save registration succesfully' do
		user = User.new(name: 'name', email: 'sample@example.com', password: '123456', password_confirmation: '123456').save 
		expect(user).to eq(true)
	end
end
	
	context 'scope tests' do
	end

	context 'Login tests' do
	it 'ensures invalid credential not logged in' do
		user = User.new(email: 'sample@example.com', password: 'password').save 
		expect(user).to eq(false)
	end

	it 'ensures valid login credential is logged in' do
		user = User.find(email: 'jops@test.com', password: 'password').save 
		expect(user).to eq(true)
	end
end	

end
