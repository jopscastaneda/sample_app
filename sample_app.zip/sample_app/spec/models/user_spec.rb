require 'rails_helper'

RSpec.describe User, type: :model do
	context 'Registration tests' do

	it 'ensures name not blank' do
		user = User.new(email: 'sample@example.com', password: '123456', password_confirmation: '123456').save 
		expect(user).to eq(false)
	end

	it 'ensures email not blank' do
		user = User.new(name: 'name', password: '123456', password_confirmation: '123456').save 
		expect(user).to eq(false)
	end

	it 'ensures password not blank' do
		user = User.new(name: 'name', email: 'sample@example.com', password_confirmation: '123456').save 
		expect(user).to eq(false)
	end

	it 'ensures password_confirmation not blank' do
		user = User.new(name: 'name', email: 'sample@example.com', password: '123456').save 
		expect(user).to eq(false)
	end

	it 'should save registration succesfully' do
		user = User.new(name: 'name', email: 'sample@example.com', password: '123456', password_confirmation: '123456').save 
		expect(user).to eq(true)
	end

	it 'ensure email format is correct' do
	end

	it 'ensure password and password_confirmation matches' do 
	end
end

	context 'Login tests' do

	it 'ensures email not blank' do
	end

	it 'ensures email format is correct' do
	end

	it 'ensures password not blank' do
	end

	it 'ensures invalid credential not logged in' do
#		user = User.find_by(email: 'sample@example.com', password_digest: '123456').save
#		expect(user).to eq(false)
	end

	it 'ensures valid login credential is logged in' do
#		user = User.find_by(email: 'jops@test.com', password_digest: '123456')
#		expect(user).to eq(true)
	end
end
end
