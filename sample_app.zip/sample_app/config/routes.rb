Rails.application.routes.draw do
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
root 'posts#index', as: 'home'

get '/registration' => 'users#index'

post '/sessions' => 'sessions#create'

post '/users' => 'users#create'

get '/dashboard' => 'posts#new'

get 'about' => 'pages#about', as: 'about'

get 'login' => 'pages#login', as: 'login'

get 'signup' => 'pages#signup', as: 'signup'
resources :posts do
	resources :comments
end


end
