class PeoplesController < ApplicationController
end
