class Signup < ApplicationRecord
end
